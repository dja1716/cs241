#include <iostream>
#include <string>
#include <vector>
#include "scanner.h"

/*
 * C++ Starter code for CS241 A3
 * All code requires C++14, so if you're getting compile errors make sure to
 * use -std=c++14.
 *
 * This file contains the main function of your program. By default, it just
 * prints the scanned list of tokens back to standard output.
 */

void outputAsBinary(int64_t n) {
	putchar(n >> 24);
	putchar(n >> 16);
	putchar(n >> 8);
	putchar(n);
}

bool overflowChecking(int64_t num) {
	return num <= 4294967295 && num >= -2147483648;
}


int main() {
  std::string line;

  try {
    while (getline(std::cin, line)) {
      // For example, just print the scanned tokens
		std::vector<Token> tokenLine = scan(line);
		int tokenLineSize = tokenLine.size();
		if (tokenLineSize > 0) {
			Token &tokenFront = tokenLine.front();
			if (tokenFront.getKind() == Token::WORD) {
				if (tokenLineSize == 2) {
					Token &tokenBack = tokenLine.back();
					Token::Kind tokenBackKind = tokenBack.getKind();


					if (tokenBackKind == Token::INT) {
						int64_t n = tokenBack.toLong();
						if (overflowChecking(n)) {
							outputAsBinary(n);
						}
						else {
							throw ScanningFailure("Error");
						}
					}
					else if (tokenBackKind == Token::HEXINT) {
						int64_t n = tokenBack.toLong();
						if (n <= 0xffffffff) {
							outputAsBinary(n);
						}
						else throw ScanningFailure("Error");
					}
					else throw ScanningFailure("Error");
				}
				else throw ScanningFailure("Error");
			}
			else throw ScanningFailure("Error");
		}
    }
  } catch (ScanningFailure &f) {
    std::cerr << f.what() << std::endl;

    return 1;
  }

  return 0;
}

