#include <iostream>
#include <string>
#include <vector>
#include "scanner.h"
using std::vector;
using std::string;
using std::pair;
/*
 * C++ Starter code for CS241 A3
 * All code requires C++14, so if you're getting compile errors make sure to
 * use -std=c++14.
 *
 * This file contains the main function of your program. By default, it just
 * prints the scanned list of tokens back to standard output.
 */

void outputAsBinary(int64_t n) {
	putchar(n >> 24);
	putchar(n >> 16);
	putchar(n >> 8);
	putchar(n);
}

bool overflowChecking(int64_t num) {
	return num <= 4294967295 && num >= -2147483648;
}


bool labelCheck(vector <pair<string, int>> &label, string name) {
	for (auto i : label) {
		if (i.first == name) {
			return true;
		}
	}
	return false;
}


void labelErr(vector <pair<string, int>> &label) {
	for (auto i : label) {
		std::cerr << i.first << " " << i.second << std::endl;
	}
}

void labelling(vector<vector<Token>> &tokenLines, vector <pair<string, int>> &label) {
	int address = 0;

	for (int i = 0; i < tokenLines.size(); i++) {
		bool isNewLine = false;
		for (int j = 0; j < tokenLines[i].size(); j++) {

			if (tokenLines[i][j].getKind() == Token::LABEL) {
				if (j > 0) {
					if (tokenLines[i][j - 1].getKind() != Token::LABEL) {
						throw ScanningFailure("Error");
					}
				}
				else {
					string name = tokenLines[i][j].getLexeme();
					name.pop_back();
					if (labelCheck(label, name)) {
						throw ScanningFailure("Error");
					}
					label.push_back(make_pair(name, address));
				}

			}

			if (!isNewLine && (tokenLines[i][j].getKind() == Token::WORD || tokenLines[i][j].getKind() == Token::ID)) {
				address += 4;
				isNewLine = true;
			}
		}
	}
}



// 


void wordChecking(vector<Token> &tokenLine, vector<long> &binary) {
	int tokenLineSize = tokenLine.size();
	if (tokenLineSize > 0) {
		Token &tokenFront = tokenLine.front();
		if (tokenFront.getKind() == Token::WORD) {
			if (tokenLineSize == 2) {
				Token &tokenBack = tokenLine.back();
				Token::Kind tokenBackKind = tokenBack.getKind();


				if (tokenBackKind == Token::INT) {
					int64_t n = tokenBack.toLong();
					if (overflowChecking(n)) {
						binary.push_back(n);
					}
					else {
						throw ScanningFailure("Error");
					}
				}
				else if (tokenBackKind == Token::HEXINT) {
					int64_t n = tokenBack.toLong();
					if (n <= 0xffffffff) {
						binary.push_back(n);
					}
					else throw ScanningFailure("Error");
				}
				else throw ScanningFailure("Error");
			}
			else throw ScanningFailure("Error");
		}
		else throw ScanningFailure("Error");
	}
}

void assembler(vector<vector<Token>> &tokenLines, vector<long> &binary) {
	for (int i = 0; i < tokenLines.size(); i++) {
		for (int j = 0; j < tokenLines[i].size(); j++) {
			wordChecking(tokenLines[i], binary);
		}
	}
}
int main() {
  std::string line;
  vector<vector<Token>> tokenLines;
  vector <long> binary;
  vector <pair<string, int>> label;

  try {
    while (getline(std::cin, line)) {
      // For example, just print the scanned tokens
		tokenLines.push_back(scan(line));
	
    }
  } catch (ScanningFailure &f) {
    std::cerr << f.what() << std::endl;



    return 1;
  }
  labelling(tokenLines, label);
  assembler(tokenLines, binary);
  labelErr(label);
  for (auto i : binary) {
	  outputAsBinary(i);
  }
  return 0;
}

